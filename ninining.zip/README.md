# 발췌기 니니닝! 🐰

텍스트를 붙여넣으면 대사는 말풍선으로, 긴 문단은 타이포그래피 원칙에 맞게 정리해 PNG 이미지로 저장하는 발췌기입니다.
빌드 과정이 없는 정적 사이트라서 GitHub Pages에 바로 올릴 수 있습니다.

## 기능

- **텍스트 → 말풍선 자동 변환**
  - 줄 전체가 `"…"` `“…”` `「…」` `『…』` 이면 대사 말풍선, `(…)` 이면 생각 말풍선
  - `이름: "대사"`, `[이름] 대사`, `이름 "대사"` 로 화자 지정
  - 빈 줄은 여백, `---` 는 구분선, `**굵게**` `*기울임*` `==형광펜==` 지원
  - 입력창 위 빠른 입력 버튼: 캐릭터 대사, 생각, 강조, 구분선을 한 번에 넣기
  - `.txt` 파일을 입력창에 끌어다 놓으면 내용이 들어감
- **템플릿 11종**: 따뜻한 종이, 책 페이지, 미니멀 화이트, 다크 노블, 메신저, 인용 카드, 손글씨 노트, 영화 자막, 파스텔, 빈티지, 레트로 터미널. 한 번 누르면 서체 · 색 · 말풍선 · 스킨이 함께 바뀌고, 글과 캐릭터는 그대로 유지
- **말풍선 모양 10가지**: 둥근, 알약, 각진, 메신저, 생각 구름, 외침, 외곽선, 점선, 세로 라인, 텍스트만
  - 미리보기에서 말풍선을 누르면 그 말풍선만 화자 · 위치 · 모양을 바꿀 수 있음
- **캐릭터**: 이름, 얼굴 사진(누르거나 끌어다 놓기), 위치, 개별 색상, 개별 말풍선 모양, 순서 변경
- **타이포그래피**: 본문 · 말풍선 · 제목 · 출처를 각각 설정. 한글 웹폰트 23종을 글꼴 모양 그대로 미리 보며 고르기 + 직접 입력, 장식 따옴표, 형광펜 색
- **장문 타이포그래피 기본값**: 한 줄 25~35자 측정 표시, 행간 1.75, 문단 간격 또는 첫 줄 들여쓰기(둘 중 하나만), 장면 전환·말풍선 뒤 첫 문단은 들여쓰기 생략, 마지막 줄 외톨이 단어 방지(`text-wrap: pretty`), 페이지 끝 문단은 줄 단위로 나눠 다음 장에 이어 붙이고 외톨이·과부 줄 방지
  - 빈 줄 1개는 문단 나눔, 2개 이상은 장면 전환 여백
- **배경**: 단색 · 그라데이션(추천 12종, 직선/원형, 각도) · 패턴(점, 격자, 줄 노트, 사선, 체크, 플러스, 종이 질감, 원고지) · 이미지
- **화면**: 1:1 · 4:5 · 3:4 · 2:3 · 9:16 · 16:9 · 4:3 · 자유 비율
  - **한 장에 맞추기**: 글자 크기를 자동으로 조절해 한 장에 꽉 차게
  - **넘치면 다음 장으로**: 긴 글을 자동으로 여러 장으로 나눔 · 페이지 번호
- **스킨**: CSS 또는 `<style>` 태그가 든 HTML을 붙여넣어 디자인을 덮어쓰기 (프리셋 7종)
- **저장 · 공유**: 1~3배 PNG, 여러 장 한 번에 저장, 클립보드 복사, 모바일 공유 시트로 바로 공유
- **편의 기능**: 실행 취소/다시 실행, 미리보기 확대/축소, 자동 저장, 설정 파일 내보내기/불러오기
- **반응형**: 웹은 3단 레이아웃, 모바일은 아래 탭 바 + 바텀 시트로 미리보기를 보면서 편집
- 시스템 다크 모드 지원

### 단축키

| 키 | 기능 |
| --- | --- |
| Ctrl/⌘ + Z | 실행 취소 (입력창 밖에서) |
| Ctrl/⌘ + Shift + Z | 다시 실행 |
| Ctrl/⌘ + S | 이미지 저장 |
| Ctrl/⌘ + `+` / `-` / `0` | 미리보기 확대 · 축소 · 화면에 맞춤 |
| Esc | 팝업 닫기 |

## GitHub Pages로 배포하기

1. GitHub에서 새 저장소를 만듭니다 (예: `excerpt-studio`).
2. 이 폴더의 파일을 저장소에 올립니다.

   ```bash
   git remote add origin https://github.com/<내 아이디>/excerpt-studio.git
   ```

   ```bash
   git push -u origin main
   ```

   또는 GitHub 웹 화면에서 **Add file → Upload files** 로 `index.html`, `style.css`, `app.js`, `lib/` 폴더를 끌어다 놓아도 됩니다.
3. 저장소의 **Settings → Pages** 에서 **Source: Deploy from a branch**, **Branch: `main` / `(root)`** 를 선택하고 저장합니다.
4. 1~2분 뒤 `https://<내 아이디>.github.io/excerpt-studio/` 에서 열립니다.

로컬에서 확인하려면 폴더에서 `python3 -m http.server` 를 실행하고 `http://localhost:8000` 을 여세요.
(`index.html` 파일을 더블클릭해서 열면 이미지 저장 시 폰트가 빠질 수 있습니다.)

## 스킨 작성법

스킨 탭에 CSS를 쓰면 기본 디자인 위에 덮어씌워집니다.

```css
/* 변수로 색만 바꾸기 */
.card {
  --card-bg: #101418;
  --text-color: #e6e6e6;
  --b-bg: #1f2933;
  --b-color: #fff;
  --name-color: #8fa3b8;
}

/* 특정 캐릭터만 */
.msg[data-speaker="도현"] .bubble { background: #ffe14d; color: #222; }

/* 눈누 등 외부 웹폰트 */
@font-face {
  font-family: 'MyFont';
  src: url('https://example.com/MyFont.woff2') format('woff2');
}
.card .narr { font-family: 'MyFont'; }
```

| 선택자 | 설명 |
| --- | --- |
| `.card` | 이미지 한 장 |
| `.card-title` / `.quote-mark` / `.card-footer` / `.credit` / `.page-num` | 제목 · 장식 따옴표 · 하단 · 출처 · 페이지 번호 |
| `.card-content` / `.flow` | 본문 영역 |
| `.narr` / `.gap` / `.divider` / `mark` | 서술 문단 · 빈 줄 · 구분선 · 형광펜 |
| `.msg` | 말풍선 한 줄 (`.msg-left` `.msg-right` `.msg-center`, `.kind-speech` `.kind-thought`, `.shape-*`) |
| `.avatar` / `.name` / `.bubble` | 사진 · 이름 · 말풍선 |

주요 변수: `--card-bg --text-color --text-font --text-size --b-bg --b-color --b-border --b-radius --b-font --name-color --title-color --credit-color --accent --hl`

> 외부 폰트를 이미지에 넣으려면 해당 폰트 서버가 CORS를 허용해야 합니다 (Google Fonts, jsDelivr, 눈누 CDN 대부분은 허용).

## 파일 구성

```
index.html             화면 구조
style.css              앱 UI + 이미지 카드 기본 스타일
app.js                 파싱 · 렌더링 · 설정 · 저장
lib/html-to-image.js   HTML → PNG 변환 라이브러리 (MIT, v1.11.11)
```
